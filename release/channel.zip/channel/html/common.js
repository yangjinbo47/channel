var timeoutFunction={
	fn : function () {
					
		swal("服务器连接异常，请检查网络重新刷新页面！");
	}
}	