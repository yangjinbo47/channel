Ext.define('CMS.model.account.OperatorModel', {
	extend : 'Ext.data.Model',
	fields : [ 'operid', 'loginName', 'name', 'password', 'roleNames', 'type', 'createtime']
});