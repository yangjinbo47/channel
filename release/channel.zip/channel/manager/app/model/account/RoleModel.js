Ext.define('CMS.model.account.RoleModel', {
	extend : 'Ext.data.Model',
	fields : [ 'roleid', 'name', 'type', 'remark', 'createoperid', 'createtime' ]
});