Ext.define('CMS.model.operation.BlackListModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'phoneNum']
});