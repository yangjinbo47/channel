Ext.define('CMS.model.operation.MobileAreaModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'firstNum', 'middleNum', 'address', 'province', 'city', 'brand']
});