Ext.define('CMS.model.operation.open.OpenMailerModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'name', 'email','select']
});