Ext.define('CMS.model.operation.open.OpenMailgroupModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'name']
});