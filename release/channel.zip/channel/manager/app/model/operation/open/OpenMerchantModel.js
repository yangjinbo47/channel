Ext.define('CMS.model.operation.open.OpenMerchantModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'merchantName', 'email', 'contact', 'telephone', 'joinType', 'merchantShowName']
});