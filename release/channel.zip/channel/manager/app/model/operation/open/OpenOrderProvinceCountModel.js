Ext.define('CMS.model.operation.open.OpenOrderProvinceCountModel', {
	extend : 'Ext.data.Model',
	fields : ['province', 'succ', 'fail', 'count', 'fee', 'rate']
});