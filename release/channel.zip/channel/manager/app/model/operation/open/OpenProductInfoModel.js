Ext.define('CMS.model.operation.open.OpenProductInfoModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'name', 'price', 'code', 'instruction', 'productId', 'type', 'merchantId', 'merchantShowName']
});