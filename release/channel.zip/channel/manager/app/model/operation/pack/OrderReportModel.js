Ext.define('CMS.model.operation.pack.OrderReportModel', {
	extend : 'Ext.data.Model',
	fields: ['sellerId','sellerName','pushId','packageName','mo','moQc','mr','fee','zhl']
});