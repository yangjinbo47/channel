Ext.define('CMS.model.operation.pack.PackageChannelModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'channelName', 'clientVersion', 'createTime','companyShow']
});