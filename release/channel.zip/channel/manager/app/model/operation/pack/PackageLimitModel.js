Ext.define('CMS.model.operation.pack.PackageLimitModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'packageId', 'province', 'dayLimit', 'monthLimit']
});