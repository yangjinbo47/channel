Ext.define('CMS.model.operation.pack.PushMailerModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'name', 'email','select']
});