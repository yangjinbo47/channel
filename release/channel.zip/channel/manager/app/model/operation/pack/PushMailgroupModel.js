Ext.define('CMS.model.operation.pack.PushMailgroupModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'name']
});