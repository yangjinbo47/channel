Ext.define('CMS.model.operation.sms.SmsMailerModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'name', 'email','select']
});