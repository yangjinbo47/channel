Ext.define('CMS.model.operation.sms.SmsMailgroupModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'name']
});