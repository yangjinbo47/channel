Ext.define('CMS.model.operation.sms.SmsMerchantModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'merchantName', 'email', 'contact', 'telephone', 'joinType', 'merchantShowName']
});