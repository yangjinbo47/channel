Ext.define('CMS.model.operation.sms.SmsOrderProvinceCountModel', {
	extend : 'Ext.data.Model',
	fields : ['province', 'succ', 'fail', 'count', 'fee', 'rate']
});