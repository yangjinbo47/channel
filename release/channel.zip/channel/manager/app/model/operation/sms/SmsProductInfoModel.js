Ext.define('CMS.model.operation.sms.SmsProductInfoModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'name', 'price', 'sendNumber', 'instruction', 'productId', 'type', 'merchantId', 'merchantShowName']
});