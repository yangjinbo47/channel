Ext.define('CMS.model.operation.sms.SmsSellerLimitModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'sellerId', 'province', 'dayLimit', 'monthLimit']
});