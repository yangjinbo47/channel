Ext.define('CMS.model.operation.thirdpart.ThirdpartMerchantModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'merchantName', 'email', 'contact', 'telephone', 'joinType', 'merchantShowName']
});