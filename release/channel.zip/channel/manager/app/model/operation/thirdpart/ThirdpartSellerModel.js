Ext.define('CMS.model.operation.thirdpart.ThirdpartSellerModel', {
	extend : 'Ext.data.Model',
	fields : ['id', 'name', 'email', 'contact', 'telephone', 'sellerKey', 'sellerSecret', 'callbackUrl','status']
});