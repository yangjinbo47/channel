Ext.define('CMS.view.operation.sms.SmsSellerModUnCheckedAppsGrid', {
	extend : 'Ext.grid.Panel',
	xtype : 'smsSellerModUnCheckedAppsGrid',
	id : 'smsSellerModUnCheckedAppsGrid',
	columnLines : true,
	layout : 'fit',
	border : false,
	loadMask : true,
	multiSelect : true,
	initComponent : function() {
		this.store = Ext.create('Ext.data.Store', {
			model : 'CMS.model.operation.sms.SmsAppModel',
//			autoLoad : true,
			proxy : {
				type : 'ajax',
				url : '../operation/smsSeller_getUnallocateApps.action',
				reader : {
					type : 'json',
					total : 'total',
					root : 'apps'
				}
			}
		});
		Ext.apply(this, {
			selModel : new Ext.selection.CheckboxModel,
			columns : [ {
				text : '序号',
				dataIndex : 'id',
				width : 50
			}, {
				text : '应用名',
				dataIndex : 'name',
				flex : 3
			}]
		});
		this.callParent(arguments);
	}
});
